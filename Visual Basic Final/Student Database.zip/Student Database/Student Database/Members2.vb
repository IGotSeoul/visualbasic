﻿Module Members
	Const intMax As Integer = 100
	Public member_code_array(intMax) As Integer
	Public age_array(intMax) As Integer
	Public member_type_array(intMax) As String
	Public first_name_array(intMax) As String
	Public last_name_array(intMax) As String
	Public gender_array(intMax) As String
	Public new_array_age(intMax) As Integer
	Public gender_search(intMax) As ArrayList

	Public count As Integer = 0
	Public i As Integer

End Module